
=begin
if move_valid(move)
next_square

square =1, value = 0
square = 1 value = 1
square = 1 value = 2
square = 1 value = 3
square = 1 value = 4
square = 2 value = 1
square = 2 value = 2
square = 2 value = 3
square = 2 value = 4
square = 3 value =1


# 0,0,0,1,1,1,2,0,1
# 00,01,02,03,04,05,06,10,13
pos[0] pos[1] % 3
3*  (i /3) +  j / 3


while i <final_square 
    move(square) # value+=1, except if value = 9 ,value =0, i-=1 then skip to beginning of loop

if move_valid?==false
    i-=1


else
    move_back
    )

end
move(next_square)
end



=end
require_relative("Board.rb")
require_relative("Tile.rb")
class Solver
POSSIBLE_VALUES=(1..9).to_a

    attr_accessor :board
    def initialize(board)
    @board = board
    end

def run
    squares=self.squares

until @board.solved?
    i=0
    iterations=0
    while i < squares.length
        print "iteration: "
        print iterations
        iterations+=1
        
        puts
        @board.render
        # sleep(3)
        # p squares[i]
        # print "square index "
        # print i
        # puts 
        # print "square value "
        # print @board.grid[squares[i][0]][squares[i][1]].value
        # puts ""
        # puts "______"
        # @board.render
        # p value_valid?(squares[i])
       
        if !move(squares[i])
            # p @board.grid[squares[i][0]][squares[i][1]].value

        #continue
        i-=2
    end
    # sleep(3)
    if !value_valid?(squares[i])
    i-=1
    # p "decrement because invalid move"
    end
i+=1
end
end
p @board.render
p "number of iterations required"
p iterations
p "solved"
end
def move(pos)
    # p "move time"
    # first=pos[0]
    # second=pos[1]

    initial_val=@board.grid[pos[0]][pos[1]].value
    # p initial_val
    
    # p [pos[0],pos[1]]
    # sleep(3)
    if initial_val != 9
    new_val=initial_val+1

@board.update(pos,new_val)
return true
    
    else
        @board.update(pos,0)
       return false
end
end
def row_valid?(pos)
@board.value_grid[pos[0]].count(@board.value_grid[pos[0]][pos[1]]) <2
end
def col_valid?(pos)
    mat = Matrix[*(@board.value_grid)]
    
    mat.column(pos[1]).count(@board.value_grid[pos[0]][pos[1]]) <2
end
def square_valid?(pos)
    # 3*  (i /3) +  j / 3
@board.turn_to_3by3[3*(pos[0]/3)+pos[1]/3].count(@board.value_grid[pos[0]][pos[1]]) < 2
#[pos[0]]
end
def squares
    arr =[]
    (0...@board.grid.length).each do |i|
        (0...@board.grid.length).each do |j|
            arr << [i,j] if @board.grid[i][j].given==false 
        end
    
    end
arr
end


    def value_valid?(pos)
    #   p "value valid time"
        row_valid?(pos)  && col_valid?(pos) && square_valid?(pos)
    end


end
sudoku1=Board.from_file("sudoku1.txt")
# hardboard= Board.from_file("hardsudoku.txt")
# hardsolver=Solver.new hardboard
# hardsolver.run
sudoku1_solver=Solver.new(sudoku1)
# sudoku2.render
sudoku1_solver.run

# solver.run